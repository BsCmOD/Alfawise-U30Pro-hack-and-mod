#ifndef	LGT_MACRO_H
#define	LGT_MACRO_H


#define RECOVER_E_ADD 4//8
#define LOAD_FILA_LEN 500
#define UNLOAD_FILA_LEN -500
#define STARTUP_COUNTER 3000
#define LED_RED 4
#define LED_GREEN 5
#define LED_BLUE 6
#define DATA_SIZE 37    //the size of ScreenData and Receive_Cmd
#define FILE_LIST_NUM  25

#define EEPROM_INDEX 4000

//Printer kill reason
#define E_TEMP_ERROR		"Error 0: abnormal E temp"   //Heating failed
#define B_TEMP_ERROR		"Error 1: abnormal B temp"   //Heating failed
#define M112_ERROR			"Error 2: emergency stop"
#define SDCARD_ERROR		"Error 3: SD card error"
#define HOME_FAILE			"Error 4: homing failed"
#define TIMEOUT_ERROR		"Error 5: timeout error"
#define EXTRUDER_NUM_ERROR  "Error 6: E number error"
#define DRIVER_ERROR		"Error 7: driver error"
#define E_MINTEMP_ERROR     "Error 8: E mintemp triggered"
#define B_MINTEMP_ERROR     "Error 9: B mintemp triggered"
#define E_MAXTEMP_ERROR     "Error 10: E maxtemp triggered"
#define B_MAXTEMP_ERROR     "Error 11: B maxtemp triggered"
#define E_RUNAWAY_ERROR     "Error 12: E thermal runaway"    // Heated, then temperature fell too far

// DWIN serial transfer protocol
#define DW_FH_0 0x5A
#define DW_FH_1 0xA5
#define DW_CMD_VAR_W 0x82
#define DW_CMD_VAR_R 0x83
#define LEN_FILE_NAME 32
#define LEN_WORD 2
#define LEN_DWORD 4
#define LEN_4_CHR 4
#define LEN_6_CHR 6

#define TEMP_RANGE 2
#define PLA_E_TEMP PREHEAT_1_TEMP_HOTEND  //200
#define PLA_B_TEMP PREHEAT_1_TEMP_BED     //60
#define ABS_E_TEMP PREHEAT_2_TEMP_HOTEND  //230
#define ABS_B_TEMP PREHEAT_2_TEMP_BED     //80

#define	MAC_LENGTH		X_BED_SIZE
#define	MAC_WIDTH	    Y_BED_SIZE
#define	MAC_HEIGHT		Z_MAX_POS
#ifdef LK1_Pro
	#define MAC_MODEL       "LK1 Pro"
	#define MAC_SIZE "220*220*250(mm)"
	//#define FILAMENT_RUNOUT_MOVE "G1 X10 Y200 F3000"
	#define FILAMENT_RUNOUT_MOVE_X 10
	#define FILAMENT_RUNOUT_MOVE_Y 200
	#define FILAMENT_RUNOUT_MOVE_F 50
#else
	#define MAC_MODEL       "LK4 Pro"
	#define MAC_SIZE "220*220*250(mm)"
	//#define FILAMENT_RUNOUT_MOVE "G1 X10 Y200 F3000"
	#define FILAMENT_RUNOUT_MOVE_X 10
	#define FILAMENT_RUNOUT_MOVE_Y 200
	#define FILAMENT_RUNOUT_MOVE_F 50
#endif // LK1_Pro
#define	BOARD_FW_VER    "Marlin1.1.9 Check-2020-05-21"
#define SCREEN_FW_VER   "LGT0.3.1 BsCmOD1.0"
// DWIN system variable address
#define DW_ADDR_CHANGE_PAGE 0x0084
#define DW_PAGE_VAR_BASE 0x5A010000UL 

// user defined variable address
#define ADDR_USER_VAR_BASE                  (0x1000)
#define ADDR_VAL_MENU_TYPE                   ADDR_USER_VAR_BASE                             // 1000
#define ADDR_VAL_BUTTON_KEY                 (ADDR_VAL_MENU_TYPE + LEN_WORD)                 // 1002
#define ADDR_VAL_LOADING			        (ADDR_VAL_BUTTON_KEY + LEN_WORD)                // 1004
#define ADDR_VAL_LAUNCH_LOGO			    (ADDR_VAL_LOADING + LEN_WORD)					// 1006
#define ADDR_TXT_ABOUT_MAC_TIME				(ADDR_VAL_LAUNCH_LOGO+LEN_WORD)                 //1008
// HOME
#define ADDR_VAL_CUR_E                      (0x1010)                                        // 1010
#define ADDR_VAL_TAR_E                      (ADDR_VAL_CUR_E + LEN_WORD)                     // 1012
#define ADDR_VAL_CUR_B                      (ADDR_VAL_TAR_E + LEN_WORD)                     // 1014
#define ADDR_VAL_TAR_B                      (ADDR_VAL_CUR_B + LEN_WORD)                     // 1016
#define ADDR_VAL_ICON_HIDE                  (ADDR_VAL_TAR_B+LEN_WORD)                       //1018
//#define ADDR_VAL_ICON_HIDE_ABL              (0x1019)                                        // 1019
// TUNE
#define ADDR_VAL_FAN                        (0x1030)                                        // 1030
#define ADDR_VAL_FEED                       (ADDR_VAL_FAN + LEN_WORD)                       // 1032    
#define ADDR_VAL_FLOW                       (ADDR_VAL_FEED + LEN_WORD)                      // 1034
#define ADDR_VAL_LEDS_SWITCH                (ADDR_VAL_FLOW + LEN_WORD)                      // 1036
#define ADDR_VAL_CUR_FEED                   (ADDR_VAL_LEDS_SWITCH+LEN_WORD)                  //1038

// LEVELING
#define ADDR_VAL_LEVEL_Z_UP_DOWN             (ADDR_VAL_CUR_FEED+LEN_WORD)                   //103A

// MOVE
#define ADDR_VAL_MOVE_POS_X                 (0x1050)                                        // 1050                  
#define ADDR_VAL_MOVE_POS_Y                 (ADDR_VAL_MOVE_POS_X + LEN_WORD)                // 1052
#define ADDR_VAL_MOVE_POS_Z                 (ADDR_VAL_MOVE_POS_Y + LEN_WORD)                // 1054
#define ADDR_VAL_MOVE_POS_E                 (ADDR_VAL_MOVE_POS_Z + LEN_WORD)                // 1056
// PRINT
	//... FILE
#define ADDR_TXT_PRINT_FILE_ITEM_0      (0x1070)                                        // 1070 
#define ADDR_TXT_PRINT_FILE_ITEM_1      (ADDR_TXT_PRINT_FILE_ITEM_0 + LEN_FILE_NAME)    // 1090
#define ADDR_TXT_PRINT_FILE_ITEM_2      (ADDR_TXT_PRINT_FILE_ITEM_1 + LEN_FILE_NAME)    // 10B0
#define ADDR_TXT_PRINT_FILE_ITEM_3      (ADDR_TXT_PRINT_FILE_ITEM_2 + LEN_FILE_NAME)    // 10D0
#define ADDR_TXT_PRINT_FILE_ITEM_4      (ADDR_TXT_PRINT_FILE_ITEM_3 + LEN_FILE_NAME)    // 10F0

#define ADDR_TXT_PRINT_FILE_ITEM_5      (ADDR_TXT_PRINT_FILE_ITEM_4 + LEN_FILE_NAME)    // 1110 
#define ADDR_TXT_PRINT_FILE_ITEM_6      (ADDR_TXT_PRINT_FILE_ITEM_5 + LEN_FILE_NAME)    // 1130
#define ADDR_TXT_PRINT_FILE_ITEM_7      (ADDR_TXT_PRINT_FILE_ITEM_6 + LEN_FILE_NAME)    // 1150
#define ADDR_TXT_PRINT_FILE_ITEM_8      (ADDR_TXT_PRINT_FILE_ITEM_7 + LEN_FILE_NAME)    // 1170
#define ADDR_TXT_PRINT_FILE_ITEM_9      (ADDR_TXT_PRINT_FILE_ITEM_8 + LEN_FILE_NAME)    // 1190

#define ADDR_TXT_PRINT_FILE_ITEM_10     (ADDR_TXT_PRINT_FILE_ITEM_9 + LEN_FILE_NAME)    // 11B0
#define ADDR_TXT_PRINT_FILE_ITEM_11     (ADDR_TXT_PRINT_FILE_ITEM_10 + LEN_FILE_NAME)   // 11D0
#define ADDR_TXT_PRINT_FILE_ITEM_12     (ADDR_TXT_PRINT_FILE_ITEM_11 + LEN_FILE_NAME)   // 11F0
#define ADDR_TXT_PRINT_FILE_ITEM_13     (ADDR_TXT_PRINT_FILE_ITEM_12 + LEN_FILE_NAME)   // 1210
#define ADDR_TXT_PRINT_FILE_ITEM_14     (ADDR_TXT_PRINT_FILE_ITEM_13 + LEN_FILE_NAME)   // 1230

#define ADDR_TXT_PRINT_FILE_ITEM_15     (ADDR_TXT_PRINT_FILE_ITEM_14 + LEN_FILE_NAME)   // 1250
#define ADDR_TXT_PRINT_FILE_ITEM_16     (ADDR_TXT_PRINT_FILE_ITEM_15 + LEN_FILE_NAME)   // 1270
#define ADDR_TXT_PRINT_FILE_ITEM_17     (ADDR_TXT_PRINT_FILE_ITEM_16 + LEN_FILE_NAME)   // 1290
#define ADDR_TXT_PRINT_FILE_ITEM_18     (ADDR_TXT_PRINT_FILE_ITEM_17 + LEN_FILE_NAME)   // 12B0
#define ADDR_TXT_PRINT_FILE_ITEM_19     (ADDR_TXT_PRINT_FILE_ITEM_18 + LEN_FILE_NAME)   // 12D0

#define ADDR_TXT_PRINT_FILE_ITEM_20     (ADDR_TXT_PRINT_FILE_ITEM_19 + LEN_FILE_NAME)   // 12F0
#define ADDR_TXT_PRINT_FILE_ITEM_21     (ADDR_TXT_PRINT_FILE_ITEM_20 + LEN_FILE_NAME)   // 1310
#define ADDR_TXT_PRINT_FILE_ITEM_22     (ADDR_TXT_PRINT_FILE_ITEM_21 + LEN_FILE_NAME)   // 1330
#define ADDR_TXT_PRINT_FILE_ITEM_23     (ADDR_TXT_PRINT_FILE_ITEM_22 + LEN_FILE_NAME)   // 1350
#define ADDR_TXT_PRINT_FILE_ITEM_24     (ADDR_TXT_PRINT_FILE_ITEM_23 + LEN_FILE_NAME)   // 1370


// PRINT home
#define ADDR_TXT_HOME_FILE_NAME             (0x1400)                                        // 1400
#define ADDR_TXT_HOME_ELAP_TIME             (ADDR_TXT_HOME_FILE_NAME + LEN_FILE_NAME)       // 1420
#define ADDR_VAL_HOME_PROGRESS              (ADDR_TXT_HOME_ELAP_TIME + LEN_6_CHR)           // 1426
#define ADDR_VAL_HOME_Z_HEIGHT              (ADDR_VAL_HOME_PROGRESS + LEN_WORD)             // 1428
// UTILITIES
	// filament
#define ADDR_VAL_UTILI_FILA_CHANGE_LEN  (0x1440)                                        // 1440
#define ADDR_VAL_FILA_CHANGE_TEMP       (ADDR_VAL_UTILI_FILA_CHANGE_LEN + LEN_WORD)     // 1442
// DIALOG NO TEMP    
#define ADDR_VAL_EXTRUDE_TEMP               (0x1460)                                        // 1460    
// ABOUT
#define ADDR_TXT_ABOUT_MODEL                (0x1480)                                        // 1480
#define ADDR_TXT_ABOUT_SIZE                 (ADDR_TXT_ABOUT_MODEL + LEN_FILE_NAME)          // 14A0
#define ADDR_TXT_ABOUT_FW_SCREEN            (ADDR_TXT_ABOUT_SIZE + LEN_FILE_NAME)           // 14C0
#define ADDR_TXT_ABOUT_FW_BOARD             (ADDR_TXT_ABOUT_FW_SCREEN + LEN_FILE_NAME)      // 14E0
#define ADDR_TXT_ABOUT_WORK_TIME_MAC         (ADDR_TXT_ABOUT_FW_BOARD+LEN_FILE_NAME)        //1500
// FILE SELECT
#define ADDR_VAL_PRINT_FILE_SELECT          (0x1550)                                        // 1550
#define ADDR_TXT_PRINT_FILE_SELECT          (ADDR_VAL_PRINT_FILE_SELECT + LEN_WORD)         // 1552  

#define ADDR_KILL_REASON                     (0x2000) 

// SP definition
#define SP_TXT_PRINT_FILE_ITEM_0            (0x6000)                                        // 6000
#define SP_COLOR_TXT_PRINT_FILE_ITEM_0		(SP_TXT_PRINT_FILE_ITEM_0 + 3)					// 6003
// ...
#define SP_TXT_PRINT_FILE_ITEM_24           (0x6300)                                        // 6300
#define SP_COLOR_TXT_PRINT_FILE_ITEM_24		(SP_TXT_PRINT_FILE_ITEM_24 + 3)					// 6303

//Tune_step_menù visualization
#define ADDR_VAL_STEPMM_X                   (0x6400)
#define ADDR_VAL_STEPMM_Y                   (0x6401)                  // 6401
#define ADDR_VAL_STEPMM_Z                   (0x6402)                  // 6402
#define ADDR_VAL_STEPMM_E                   (0x6403)                  // 6403
#define ADDR_VAL_FEEDRATE_X                 (0x6404)                  // 6404
#define ADDR_VAL_FEEDRATE_Y                 (0x6405)                  // 6405
#define ADDR_VAL_FEEDRATE_Z                 (0x6406)                  // 6406
#define ADDR_VAL_FEEDRATE_E                 (0x6407)                  // 6407
#define ADDR_VAL_ACC_X                      (0x6408)                  // 6408
#define ADDR_VAL_ACC_Y                      (0x6409)                  // 6409
#define ADDR_VAL_ACC_Z                      (0x64A0)                  // 64A0
#define ADDR_VAL_ACC_E                      (0x64B0)                  // 64B0
#define ADDR_VAL_ACC_P                      (0x64C0)                  // 64C0
#define ADDR_VAL_ACC_R                      (0x64D0)                  // 64D0
#define ADDR_VAL_JERK_X                     (0x64E0)                  // 64E0
#define ADDR_VAL_JERK_Y                     (0x64F0)                  // 64F0
#define ADDR_VAL_JERK_Z                     (0x6410)                  // 6410
#define ADDR_VAL_JERK_E                     (0x6411)                  // 6411
//#define ADDR_VAL_Z_OFFSET                   (0x6412)                  // 6412
#define ADDR_VAL_ACC_T                      (0x6413)                  // 6413 

// color
#define COLOR_LIGHT_RED                     (0xA001)
#define COLOR_WHITE							(0xFFFF)
// color_change(SP_TXT_PRINT_FILE_ITEM_0 + i*LEN_FILE_NAME, COLOR_LIGHT_RED)  


enum E_BUTTON_KEY {

	eBT_MOVE_XY_HOME,           //0  0000
	eBT_MOVE_Z_HOME,
	eBT_MOVE_X_PLUS_0,
	eBT_MOVE_X_MINUS_0,
	eBT_MOVE_Y_PLUS_0,
	eBT_MOVE_Y_MINUS_0,         //5  0005
	eBT_MOVE_Z_PLUS_0,
	eBT_MOVE_Z_MINUS_0,
	eBT_MOVE_E_PLUS_0,
	eBT_MOVE_E_MINUS_0,

	eBT_MOVE_X_PLUS_1,          // 10  000A 
	eBT_MOVE_X_MINUS_1,
	eBT_MOVE_Y_PLUS_1,
	eBT_MOVE_Y_MINUS_1,
	eBT_MOVE_Z_PLUS_1,
	eBT_MOVE_Z_MINUS_1,         //15  000F
	eBT_MOVE_E_PLUS_1,
	eBT_MOVE_E_MINUS_1,

	eBT_MOVE_X_PLUS_2,
	eBT_MOVE_X_MINUS_2,
	eBT_MOVE_Y_PLUS_2,          //20 0014
	eBT_MOVE_Y_MINUS_2,
	eBT_MOVE_Z_PLUS_2,
	eBT_MOVE_Z_MINUS_2,
	eBT_MOVE_E_PLUS_2,
	eBT_MOVE_E_MINUS_2,         //25 0019
	eBT_MOVE_DISABLE,
	eBT_MOVE_ENABLE,
	eBT_PRINT_FILE_OPEN,
	eBT_PRINT_FILE_OPEN_YES,

	eBT_PRINT_HOME_PAUSE,       //30  001E
	eBT_PRINT_HOME_RESUME,
	eBT_PRINT_HOME_ABORT,
	eBT_PRINT_HOME_FINISH,

	eBT_UTILI_FILA_PLA,
	eBT_UTILI_FILA_ABS,         //35  0023
	eBT_UTILI_FILA_LOAD,
	eBT_UTILI_FILA_UNLOAD,

	eBT_HOME_RECOVERY_YES,
	eBT_HOME_RECOVERY_NO,
	eBT_DIAL_FILA_NO_TEMP_RET,    //40 0028
	eBT_DIAL_MOVE_NO_TEMP_RET,
	eBT_PRINT_FILE_CLEAN,

	eBT_UTILI_LEVEL_MEASU_START,  // == PREVIOUS
	eBT_UTILI_LEVEL_CORNER_POS_1,
	eBT_UTILI_LEVEL_CORNER_POS_2, //45 002D
	eBT_UTILI_LEVEL_CORNER_POS_3,
	eBT_UTILI_LEVEL_CORNER_POS_4,
	eBT_UTILI_LEVEL_CORNER_POS_5,
	eBT_UTILI_LEVEL_MEASU_DIS_0,
	eBT_UTILI_LEVEL_MEASU_DIS_1,    //50 0032
	eBT_UTILI_LEVEL_MEASU_S1_NEXT,

	eBT_UTILI_LEVEL_MEASU_S2_NEXT,
	eBT_UTILI_LEVEL_MEASU_S1_EXIT_NO,
	eBT_UTILI_LEVEL_MEASU_S2_EXIT_NO,
	eBT_UTILI_LEVEL_MEASU_EXIT_OK,     //55  0037
	eBT_UTILI_LEVEL_MEASU_S3_EXIT_NO,
	eBT_MOVE_P0,       
	eBT_MOVE_P1,
	eBT_MOVE_P2,
	eBT_TUNE_SWITCH_LEDS,			//60  003C
	eBT_UTILI_LEVEL_MEASU_STOP_MOVE,
	eBT_UTILI_LEVEL_CORNER_BACK,
	eBT_PRINT_FILA_CHANGE_YES,
	eBT_PRINT_FILA_HEAT_NO,
	eBT_PRINT_FILA_UNLOAD_OK,		//65 0041
	eBT_PRINT_FILA_LOAD_OK,
	//eBT_AUTO_BED_LEVELING,          //67 0043
	//eBT_BABYSTEP_PLUS_0,            //68 0044
	//eBT_BABYSTEP_MINUS_0,           //69 0045
	//eBT_BABYSTEP_PLUS_1,            //70 0046
	//eBT_BABYSTEP_MINUS_1,           //71 0047
	//eBT_AUTO_BED_LEVELING_M500,     //72 0048
	
	eBT_STEPMM_X0_PLUS,             //73 0049
	eBT_STEPMM_X0_MINUS,            //74 004A
	eBT_STEPMM_X1_PLUS,             //75 004B
	eBT_STEPMM_X1_MINUS,            //76 004C
	eBT_STEPMM_Y0_PLUS,             //77 004D
	eBT_STEPMM_Y0_MINUS,            //78 004E
	eBT_STEPMM_Y1_PLUS,             //79 004F
	eBT_STEPMM_Y1_MINUS,            //80 0050
	eBT_STEPMM_Z0_PLUS,             //81 0051
	eBT_STEPMM_Z0_MINUS,            //82 0052
	eBT_STEPMM_Z1_PLUS,             //83 0053
	eBT_STEPMM_Z1_MINUS,            //84 0054
	eBT_STEPMM_E0_PLUS,             //85 0055
	eBT_STEPMM_E0_MINUS,            //86 0056
	eBT_STEPMM_E1_PLUS,             //87 0057
	eBT_STEPMM_E1_MINUS,            //88 0058
	
	eBT_FEEDRATE_X0_PLUS,           //89 0059
	eBT_FEEDRATE_X0_MINUS,          //90 005A
	eBT_FEEDRATE_X1_PLUS,           //91 005B
	eBT_FEEDRATE_X1_MINUS,          //92 005C
	eBT_FEEDRATE_Y0_PLUS,           //93 005D
	eBT_FEEDRATE_Y0_MINUS,          //94 005E
	eBT_FEEDRATE_Y1_PLUS,           //95 005F
	eBT_FEEDRATE_Y1_MINUS,          //96 0060
	eBT_FEEDRATE_Z0_PLUS,           //97 0061
	eBT_FEEDRATE_Z1_MINUS,          //98 0062
	eBT_FEEDRATE_Z1_PLUS,           //99 0063
	eBT_FEEDRATE_Z0_MINUS,          //100 0064
	eBT_FEEDRATE_E0_PLUS,           //101 0065
	eBT_FEEDRATE_E0_MINUS,          //102 0066
	eBT_FEEDRATE_E1_PLUS,           //103 0067
	eBT_FEEDRATE_E1_MINUS,          //104 0068
	
	eBT_ACC_X0_PLUS,                //105 0069
	eBT_ACC_X0_MINUS,               //106 006A
	eBT_ACC_X1_PLUS,                //107 006B
	eBT_ACC_X1_MINUS,               //108 006C
	eBT_ACC_Y0_PLUS,                //109 006D
	eBT_ACC_Y0_MINUS,               //110 006E
	eBT_ACC_Y1_PLUS,                //111 006F
	eBT_ACC_Y1_MINUS,               //112 0070
	eBT_ACC_Z0_PLUS,                //113 0071
	eBT_ACC_Z0_MINUS,               //114 0072
	eBT_ACC_Z1_PLUS,                //115 0073
	eBT_ACC_Z1_MINUS,               //116 0074
	eBT_ACC_E0_PLUS,                //117 0075
	eBT_ACC_E0_MINUS,               //118 0076
	eBT_ACC_E1_PLUS,                //119 0077
	eBT_ACC_E1_MINUS,               //120 0078
	
	eBT_ACC_P0_PLUS,                //121 0079
	eBT_ACC_P0_MINUS,               //122 007A
	eBT_ACC_P1_PLUS,                //123 007B
	eBT_ACC_P1_MINUS,               //124 007C
	
	eBT_ACC_R0_PLUS,                //125 007D
	eBT_ACC_R0_MINUS,               //126 007E
	eBT_ACC_R1_PLUS,                //127 007F
	eBT_ACC_R1_MINUS,               //128 0080

	eBT_JERK_X0_PLUS,               //129 0081
	eBT_JERK_X0_MINUS,              //130 0082
	eBT_JERK_X1_PLUS,               //131 0083
	eBT_JERK_X1_MINUS,              //132 0084
	eBT_JERK_Y0_PLUS,               //133 0085
	eBT_JERK_Y0_MINUS,              //134 0086
	eBT_JERK_Y1_PLUS,               //135 0087
	eBT_JERK_Y1_MINUS,              //136 0088
	eBT_JERK_Z0_PLUS,               //137 0089
	eBT_JERK_Z0_MINUS,              //138 008A
	eBT_JERK_Z1_PLUS,               //139 008B
	eBT_JERK_Z1_MINUS,              //140 008C
	eBT_JERK_E0_PLUS,               //141 008D
	eBT_JERK_E0_MINUS,              //142 008E
	eBT_JERK_E1_PLUS,               //143 008F
	eBT_JERK_E1_MINUS,              //144 0090

	//eBT_Z_OFFSET0_PLUS,             //145 0091
	//eBT_Z_OFFSET0_MINUS,            //146 0092
	//eBT_Z_OFFSET1_PLUS,             //147 0093
	//eBT_Z_OFFSET1_MINUS,            //148 0094

	eBT_STEPMM_X_DEFAULT,           //149 0095
	eBT_STEPMM_Y_DEFAULT,           //150 0096
	eBT_STEPMM_Z_DEFAULT,           //151 0097
	eBT_STEPMM_E_DEFAULT,           //152 0098

	eBT_FEEDRATE_X_DEFAULT,         //153 0099
	eBT_FEEDRATE_Y_DEFAULT,         //154 009A
	eBT_FEEDRATE_Z_DEFAULT,         //155 009B
	eBT_FEEDRATE_E_DEFAULT,         //156 009C

	eBT_ACC_X_DEFAULT,              //157 009D
	eBT_ACC_Y_DEFAULT,              //158 009E
	eBT_ACC_Z_DEFAULT,              //159 009F
	eBT_ACC_E_DEFAULT,              //160 00A0

	eBT_ACC_P_DEFAULT,              //161 00A1
	eBT_ACC_R_DEFAULT,              //162 00A2

	eBT_JERK_X_DEFAULT,             //163 00A3
	eBT_JERK_Y_DEFAULT,             //164 00A4
	eBT_JERK_Z_DEFAULT,             //165 00A5
	eBT_JERK_E_DEFAULT,             //166 00A6

	//eBT_Z_OFFSET_ZERO,              //167 00A7

	eBT_SAVETOEEPROM,               //168 00A8

	eBT_ACC_T0_PLUS,                //169 00A9
	eBT_ACC_T0_MINUS,               //170 00AA
	eBT_ACC_T1_PLUS,                //171 00AB
	eBT_ACC_T1_MINUS,               //172 00AC

	eBT_ACC_T_DEFAULT,              //173 00AD

	//eBT_ABL_ON_OFF,                 //174 00AE
	eBT_REFRESH_SD                  //175 00AF
};

enum E_MENU_TYPE {

	eMENU_IDLE,         // 0
	eMENU_HOME,
	eMENU_TUNE,         // 2
	eMENU_MOVE,
	eMENU_TUNE_E,       // 4
	eMENU_TUNE_B,
	eMENU_TUNE_FAN,     // 6
	eMENU_TUNE_SPEED,
	eMENU_TUNE_FLOW,    // 8 
	eMENU_UTILI_FILA,
	eMENU_PRINT_HOME,   // 10 000A  
	eMENU_HOME_FILA,
	eMENU_FILE			//12  000C
	// eMENU_ABL           //13  000D

};

#define ID_MENU_HOME                (1)
#define ID_MENU_PRINT_HOME          (45)
#define ID_MENU_PRINT_HOME_PAUSE    (46)
#define ID_MENU_PRINT_TUNE			(47)
#define ID_MENU_PRINT_FILES_O		(21)

#define ID_DIALOG_PRINT_RECOVERY    (93)
#define ID_DIALOG_NO_FILA           (85)
#define ID_DIALOG_PRINT_START_0     (26)
#define ID_DIALOG_PRINT_START_1     (96)
#define ID_DIALOG_PRINT_FINISH      (81)
#define ID_DIALOG_FILA_NO_TEMP      (91)
#define ID_DIALOG_MOVE_NO_TEMP      (94)
#define ID_DIALOG_MOVE_WAIT         (126)
#define ID_DIALOG_PRINT_WAIT		(127)
#define ID_DIALOG_PRINT_TUNE_WAIT   (133)
#define ID_DIALOG_LEVEL_WAIT        (128)
#define ID_DIALOG_LEVEL_FAILE       (129)
#define ID_DIALOG_PRINT_LEVEL_FAILE (146)
#define ID_DIALOG_UTILI_FILA_WAIT	(139)
#define ID_DIALOG_UTILI_FILA_LOAD	(140)
#define ID_DIALOG_UTILI_FILA_UNLOAD	(141)
#define ID_DIALOG_LOAD_FINISH       (144)
//#define ID_DIALOG_ABL_WAIT          (154)
//#define ID_DIALOG_ABL_MENU          (151)

#define ID_DIALOG_PRINT_FILA_WAIT	(134)
#define ID_DIALOG_PRINT_FILA_LOAD	(135)
#define ID_DIALOG_PRINT_FILA_UNLOAD	(136)

#define ID_MENU_UTILI_FILA_0        (87)
#define ID_MENU_HOME_FILA_0         (100)
#define ID_MENU_MOVE_0              (3)
#define ID_MENU_MOVE_1              (36)
#define ID_CRASH_KILLED             (107)
#define ID_MENU_MEASU_S1            (112)
#define ID_MENU_MEASU_S2            (114)
#define ID_MENU_MEASU_S3            (116)
#define ID_MENU_MEASU_FINISH        (123)

//===========================================================================
//===========================   PRINTER ABOUT   =============================
//===========================================================================

//#define	MAC_LENGTH		X_BED_SIZE
//#define	MAC_WIDTH	    Y_BED_SIZE
//#define	MAC_HEIGHT		Z_MAX_POS
//#define	BOARD_FW_VER    SHORT_BUILD_VERSION // " Ver 1.10.0"

#endif  //LGT_MACRO_H
